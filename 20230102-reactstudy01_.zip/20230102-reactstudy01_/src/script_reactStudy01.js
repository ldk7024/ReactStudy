// object shorthand assignment
let name = "daegyo";
let age = 27;

let person ={
  name,
  age
}

// console.log(person);

// Destructuring
let person1 ={
  name1: "daegyo",
  age1: 20
}
// let name = person.name
// let age = person['age']
let{name1,age1}= person1

// console.log(name1,age1);

let array = [1,2,3,4];
// let [a,b,c] = array
let [a,b,...rest] = array
// console.log(rest);

// spread
// let person2 = {name2:"ddd", age2=1312}
// let person3 = {...person2} 
// console.log(person3);

let aa22 = {name:"갹갹이",age:1111};
let aa33 = {...aa22} // 객체의 내용을 복사
let aa44 = aa22 // 주소값만 덛씌워짐
 
let a3= [1,2]
let b3=[...a3,3]

console.log(b3) // a 내용에 3이 추가됨
// ... -> 객체를 복사해서 그 내용을 그대로 가져온다.

// 삼항연산자
let sky = null // fase
if(sky){
  console.log(person.name)
}else{
  console.log("갹갹");
}

// 리액트 문법
console.log(person?person.name:"there is no name")